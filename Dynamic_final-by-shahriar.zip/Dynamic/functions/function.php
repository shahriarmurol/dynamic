<?php
	function get_header(){
		require_once('includes/header.php');	
	}
	
	function get_banner(){
		include_once('includes/banner.php');	
	}
	
	function get_part($addpart){
		include_once('includes/'.$addpart);	
	}
	
	function left_sidebar(){
		include_once('includes/left_sidebar.php');	
	}
	
	function right_sidebar(){
		include_once('includes/right_sidebar.php');	
	}
	
	function get_footer(){
		require_once('includes/footer.php');	
	}
?>