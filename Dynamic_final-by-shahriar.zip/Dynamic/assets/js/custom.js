// $(document).ready(function(){
// 	$('#nav a').click(function(){
// 		//remove the prev select mene class
// 		$('#nav').find('li.current').removeClass('current');
// 		//adding the state for this parent menu class
// 		$(this).parents("li").addClass('current');
// 	});
// });