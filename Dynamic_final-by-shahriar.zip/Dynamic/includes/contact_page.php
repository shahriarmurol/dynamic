<?php 
  require_once('config.php');
  if(isset($_POST['contact-form'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $url = $_POST['url'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    if(!empty($name)){
      $insert = "INSERT INTO messages(name, email, url, subject, message) VALUES('$name', '$email', '$url', '$subject', '$message')";
      $qre = mysqli_query($dbc, $insert);
      if($qre){
        echo "Message has ben insert successfully";
      }else{
        echo "Message send faild!";
      }
    }else{
      echo "Name & Email & message must not empty";
    }

  }
?>
<div class="5u 12u(narrower) important(narrower)">
    <div id="content">
        <article>
            <header>
                <h2>Contact Us</h2>
                <!-- contact form -->
 <div class="12u">  
  <form id="contact" action="" method="post">
    <h4>Contact us for custom quote</h4>
    <fieldset>
      <input placeholder="Your name" type="text" name="name" tabindex="1" autofocus>
    </fieldset>
    <fieldset>
      <input placeholder="Your Email Address" type="email" name="email" tabindex="2">
    </fieldset>
    <fieldset>
      <input placeholder="Your Web Site (optional)" type="url" name="url" tabindex="4">
    </fieldset>
    <fieldset>
      <input placeholder="Subject" type="text" name="subject" tabindex="2">
    </fieldset>
    <fieldset>
      <textarea placeholder="Type your message here...." name="message" tabindex="5"></textarea>
    </fieldset>
    <fieldset>
      <button type="submit" name="contact-form" id="contact-submit" data-submit="...Sending">Submit</button>
    </fieldset>
  </form>
</div>
            </header>
           
        </article>
    </div>
</div>