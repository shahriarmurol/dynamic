<?php
	require_once('functions/function.php');
	get_header();
?>
        <section class="wrapper style1">
            <div class="container">
                <div id="content">

                        <article>
                            <header>
                                <h2>Gallery Page</h2>
                                <p>All content, all the time.</p>
                            </header>

                            <span class="image featured"><img src="images/banner.jpg" alt="" /></span>

                        </article>

                </div>
            </div>
        </section>
<?php
	get_footer();
?>