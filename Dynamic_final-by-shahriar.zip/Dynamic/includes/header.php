<?php 
    //this line gets the file name without the dot extension
    $menuLinkId = basename($_SERVER['PHP_SELF'], ".php");
    if($menuLinkId  == "index"){
        $index = "current";
    }else if($menuLinkId == "about"){
        $about = "current";
    }else if($menuLinkId == "contact"){
        $contact = "current";
    }else if($menuLinkId == "gallery"){
        $gallery = "current";
    }else if($menuLinkId == "contact"){
        $contact = "current";
    }else if($menuLinkId == "service"){
        $service = "current";
    }
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Arcana by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>
        <!-- <?php //include_once("menu_template.php"); ?> -->
		<div id="page-wrapper">
            <div id="header">
                    <!-- menu start -->
                    <nav id="nav">
                        <ul>
                            <li class="<?=$index;?>"> <a  href="index.php">Home</a></li>
                            <li class="<?=$about;?>"> <a href="about.php">About Us</a></li>
                            <li class="<?=$gallery;?>"> <a href="gallery.php">Gallery</a></li>
                              <li class="<?= $service;?>"> <a href="service.php">Our Service</a></li>
                            <li class="<?=$contact;?>"> <a href="contact.php">Contact Us</a></li>
                        </ul>
                    </nav>
                    <!-- / menu -->
                </div>
