<?php
	require_once('functions/function.php');
	get_header();
	get_banner();
	get_part('home_page.php');
	get_footer();

?>				