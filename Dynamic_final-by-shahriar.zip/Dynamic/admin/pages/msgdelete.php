<?php 
  	require_once('../../includes/config.php');
	$id = $_REQUEST['did'];
  	$slt = "DELETE FROM messages WHERE id='$id' ";
  	$qre=mysqli_query($dbc, $slt);
  	header("Location: ../../admin/pages/messages.php");

?> 